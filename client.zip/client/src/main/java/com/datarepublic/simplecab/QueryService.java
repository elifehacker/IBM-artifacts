package com.datarepublic.simplecab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class QueryService implements SimpleCabService{
    
    HashMap<String, Integer> cache;
    
    public QueryService(){
        cache = new HashMap<String, Integer>();
    }    
    
    @Override
    public void deleteCache(){
        System.out.println("Delete Cache"); 
        cache = new HashMap<String, Integer>();
    }

    @Override
    public void getMedallionsSummary(String medallions, Date pickupDate) {
        //return how many trips each medallion has made
        getMedallionsSummary(medallions, pickupDate, false);
        //return null;
    }

    @Override
    public void getMedallionsSummary(String medallions, Date pickupDate, boolean ignoreCache) {
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String pDate = dateFormat.format(pickupDate);
        String[] split = medallions.split(",");
        //LinkedList<String> list = new LinkedList<String>();

        for(String medallion: split){
            boolean query = false;
            if(ignoreCache){
                query = true;
            }else{
                if(cache.containsKey(medallion+pDate)){
                    //list.add(medallion+" "+cache.get(medallion+pDate));
                    System.out.println("Found in cache "+medallion+" "+cache.get(medallion+pDate)); 
                }else{
                    query = true;
                }
            }
            if(query){
                int result = queryDB(medallion, pDate);
                cache.put(medallion+pDate, result);
                //list.add(medallion+" "+result); 
            }
        }
        //return list;
    }

    private int queryDB(String medallion, String pDate) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ny_cab_data?autoReconnect=true&useSSL=false", "root", "password");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT Count(*) from cab_trip_data WHERE medallion = '"+medallion+"' AND "
                    + "pickup_datetime >= '"+pDate+" 00:00:00' AND pickup_datetime <= '"+pDate+" 23:59:59'");
            rs.first();
            int result = rs.getInt(1);
            System.out.println("Query DB result "+medallion+" "+result); 
            /*
            while (rs.next())
            {
              String meda = rs.getString("medallion");
              Date date = rs.getDate("pickup_datetime");
              System.out.format("%s, %s\n", meda, date);
            }*/
            st.close();
            return result;
        }catch (SQLException e){
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return -1;
    }

}

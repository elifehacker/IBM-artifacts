package com.datarepublic.simplecab;

import java.sql.ResultSet;
import java.util.Date;

public interface SimpleCabService {

  void deleteCache();

  void getMedallionsSummary(String medallions, Date pickupDate);

  void getMedallionsSummary(String medallions, Date pickupDate, boolean ignoreCache);

}

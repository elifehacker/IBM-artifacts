package com.datarepublic.simplecab;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Client {

    public SimpleCabService service;
    private static Date pickupDate;
    private static String medallions;
    private static String url;
    private static String user;
    private static String password;
    public Client(SimpleCabService s){
        service = s;
    }
    
  public static void main(String[] args){
    //TODO you would need to implement a basic CLI here
    
    //"jdbc:mysql://localhost:3306/ny_cab_data?autoReconnect=true&useSSL=false", "root", "password"
    Scanner reader = new Scanner(System.in);  // Reading from System.in
    Client client = null;
    do{
        try{
            getDBDetail(reader);
            client = new Client(new QueryService(url, user, password));
        }catch(Exception e){
            e.printStackTrace();
        }
    }while(!client.service.testConnection());
    
    while(true){
        try{
            System.out.println("Please enter a a number to run the following \n1.getMedallionsSummary\n2.getMedallionsSummary with cache flag\n3.deleteCache ");
            String command = reader.next(); 
            if(command.equals("1")){
                getInput(reader);
                client.service.getMedallionsSummary(medallions, pickupDate);

            }else if(command.equals("2")){
                getInput(reader);
                System.out.println("ignoreCache 1:true 2:false");
                String cache = reader.next(); 
                if(cache.equals("1")){
                    client.service.getMedallionsSummary(medallions, pickupDate, true);
                }else if(cache.equals("2")){
                    client.service.getMedallionsSummary(medallions, pickupDate, false);
                }
            }else if(command.equals("3")){
                client.service.deleteCache();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /* 
    //test
    String medallions = "D7D598CD99978BD012A87A76A7C891B7,5455D5FF2BD94D10B304A15D4B7F2735";
    Date pickupDate = new SimpleDateFormat("yyyy-MM-dd").parse("2013-12-01");
    client.service.getMedallionsSummary(medallions, pickupDate);
    client.service.getMedallionsSummary(medallions, pickupDate); //find in cache
    client.service.getMedallionsSummary(medallions, pickupDate, true); 
    client.service.getMedallionsSummary(medallions, pickupDate); //find in cache
    client.service.deleteCache();
    client.service.getMedallionsSummary(medallions, pickupDate); //not find in cache
    client.service.getMedallionsSummary(medallions, pickupDate, false); //find in cache
    */
  }
  
  private static void getInput(Scanner reader) throws ParseException{
      System.out.println("Enter a date in yyyy-MM-dd format(eg.2013-12-01): ");
      String pDate = reader.next(); 
      pickupDate = new SimpleDateFormat("yyyy-MM-dd").parse(pDate);
      System.out.println("Enter medallions separated by comma (eg.D7D598CD99978BD012A87A76A7C891B7,5455D5FF2BD94D10B304A15D4B7F2735): ");
      medallions = reader.next(); 
  }
  
    private static void getDBDetail(Scanner reader) throws ParseException{
      System.out.println("Please provide your database url eg.jdbc:mysql://localhost:3306/ny_cab_data?autoReconnect=true&useSSL=false :");
      url = reader.next(); 
      System.out.println("database user name eg.root :");
      user = reader.next(); 
      System.out.println("user password:");
      password = reader.next(); 
  }

}
